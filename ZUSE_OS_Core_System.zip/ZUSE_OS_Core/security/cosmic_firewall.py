# ZUSE OS Quantum Firewall
def scan_signal(signal):
    if 'malicious' in signal:
        return '⚠️ Blocked'
    return '✅ Safe'
