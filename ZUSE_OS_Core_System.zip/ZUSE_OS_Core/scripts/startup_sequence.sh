#!/bin/bash
echo '🔭 Booting ZUSE OS...'
python3 ../core/zuse_core.py
